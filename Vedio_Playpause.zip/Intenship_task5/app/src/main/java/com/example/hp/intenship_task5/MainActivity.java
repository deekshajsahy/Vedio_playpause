package com.example.hp.intenship_task5;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    Button play;
    VideoView vedio;
    MediaController media;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play=(Button)findViewById(R.id.play);
        vedio=findViewById(R.id.vedio);
        media=new MediaController(this);

    }
    public void videoplay(View v)
    {
        String videopath="android.resource://com.example.hp.intenship_task5/"+R.raw.baby;
        Uri uri=Uri.parse(videopath);
        vedio.setVideoURI(uri);
        vedio.setMediaController(media);
        media.setAnchorView(vedio);
        vedio.start();
    }
}
